# Attribution

이 튜토리얼 프로젝트는 Apple의 TabletopKit 샘플 **Simulating dice rolls as a component for your game**에서 장비 구성, toss interaction, face mapping의 초기 구조를 참고하고 일부 코드를 수정해 사용합니다.

Apple 샘플에서 유래한 부분은 프로젝트의 `LICENSE.txt`와 Apple Sample Code License를 따릅니다.
