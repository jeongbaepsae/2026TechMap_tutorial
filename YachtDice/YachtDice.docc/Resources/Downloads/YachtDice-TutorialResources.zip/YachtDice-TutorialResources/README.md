# Yacht Dice Tutorial Resources

TabletopKit 튜토리얼에서 사용하는 3D asset입니다.

```text
YachtDice-TutorialResources/
├─ dice/
│  └─ D6.usdz
└─ table/
   ├─ table.usda
   └─ textures/
```

새 visionOS 프로젝트를 만든 뒤 `dice`와 `table` 폴더를 다음 위치에 복사하세요.

```text
Packages/RealityKitContent/Sources/RealityKitContent/RealityKitContent.rkassets/
```

Swift에서는 `realityKitContentBundle`을 사용해 다음 경로로 asset을 로드합니다.

```swift
Entity.load(named: "table/table", in: realityKitContentBundle)
ModelEntity.load(named: "dice/D6", in: realityKitContentBundle)
```

튜토리얼 다운로드 용량을 줄이기 위해 table texture는 1024×1024로 최적화되어 있습니다.
